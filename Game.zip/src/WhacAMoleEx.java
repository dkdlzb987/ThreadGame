import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class WhacAMoleEx extends JFrame implements ActionListener {
	JPanel pnlNorth, pnlCenter;
	JButton btn[];
	JButton start;
	JLabel lblTime, lblScore;
	int i;
	countDown cd;

	public WhacAMoleEx() {
		this.setSize(500, 500);
		this.setDefaultCloseOperation(3);
		pnlNorth = new JPanel();
		cd = new countDown();
		JLabel space = new JLabel("                              ");
		lblScore = new JLabel("���� : 0");
		start = new JButton("����");
		start.addActionListener(this);

		
		lblScore.setFont(new Font("����", Font.BOLD, 20));

		pnlNorth.add(cd);
		pnlNorth.add(space);
		pnlNorth.add(start);
		pnlNorth.add(lblScore);

		this.add(pnlNorth, "North");

		pnlCenter = new JPanel(new GridLayout(0, 3, 40, 40));
		btn = new JButton[9];
		for (i = 0; i < btn.length; i++) {
			btn[i] = new JButton();
			btn[i].setBorder(BorderFactory.createLineBorder(Color.BLUE));
			btn[i].addActionListener(this);
			pnlCenter.add(btn[i]);
		}

		this.add(pnlCenter);

		this.setVisible(true);
	}

	public static void main(String[] args) {
		new WhacAMoleEx();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == start) {
			
			(new Thread(cd)).start();
			
		}

	}
}
