import java.awt.Font;

import javax.swing.JLabel;

public class countDown extends JLabel implements Runnable {
	
	public countDown() {
		this.setText("�ð� : 100��");
		this.setFont(new Font("����", Font.BOLD, 20));
	}
	
	@Override
	public void run() {
		while(true){
			for (int i = 100; i >= 0; i--) {
				try {
					Thread.sleep(1000);

				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				this.setText("�ð� : " + i + "��");
			}
		}
	}
}
